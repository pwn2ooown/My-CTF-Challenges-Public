#!/bin/sh

exec 2>/dev/null
cd /home/zero_to_hero_revenge
timeout 60 /home/zero_to_hero_revenge/zero_to_hero_revenge